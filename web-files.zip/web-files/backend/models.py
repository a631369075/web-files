from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash

db = SQLAlchemy()

# 用户模型
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # 设置密码（哈希存储）
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    # 验证密码
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    # 转为字典（前端适配）
    def to_dict(self):
        return {
            'id': self.id,
            'username': self.username,
            'created_at': self.created_at.strftime('%Y-%m-%d %H:%M:%S')
        }

# 文件模型
class File(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), nullable=False)  # 文件名
    path = db.Column(db.String(512), nullable=False, unique=True)  # 文件路径
    extension = db.Column(db.String(20))  # 文件后缀
    category = db.Column(db.String(20))  # 文件分类（pdf/word/excel/images）
    size = db.Column(db.Integer)  # 文件大小（字节）
    mime_type = db.Column(db.String(100))  # MIME类型
    last_modified = db.Column(db.DateTime)  # 最后修改时间
    created_at = db.Column(db.DateTime, default=datetime.utcnow)  # 入库时间

    # 转为字典（前端适配）
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'extension': self.extension,
            'category': self.category,
            'size': self.size,
            'mime_type': self.mime_type,
            'last_modified': self.last_modified.strftime('%Y-%m-%d %H:%M:%S') if self.last_modified else None,
            'created_at': self.created_at.strftime('%Y-%m-%d %H:%M:%S')
        }
