from backend.models import db, User

def init_db(app=None):
    """初始化数据库：创建表+默认管理员（admin/admin123）"""
    # 如果传入app，绑定上下文（首次启动用）
    if app:
        with app.app_context():
            create_tables_and_admin()
    else:
        create_tables_and_admin()

def create_tables_and_admin():
    # 创建所有数据库表
    db.create_all()

    # 检查是否已有管理员用户
    admin = User.query.filter_by(username='admin').first()
    if not admin:
        # 创建默认管理员（密码：admin123，登录后建议修改）
        admin = User(username='admin')
        admin.set_password('admin123')
        db.session.add(admin)
        db.session.commit()
        print("默认管理员创建成功：用户名=admin，密码=admin123（请登录后修改）")
    else:
        print("管理员用户已存在")
