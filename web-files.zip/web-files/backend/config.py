import os

class Config:
    # 安全配置（群晖需自定义密钥）
    SECRET_KEY = os.environ.get('SECRET_KEY', 'default-dev-key-change-in-production')  # 生产环境需替换
    DEBUG = os.environ.get('DEBUG', 'False').lower() == 'true'

    # 数据库配置（SQLite，群晖容器内存储）
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
    SQLALCHEMY_DATABASE_URI = f"sqlite:///{os.path.join(BASE_DIR, 'file_manager.db')}"
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    # 文件存储配置（适配群晖容器挂载）
    FILE_STORAGE_PATH = os.path.join(os.path.dirname(BASE_DIR), 'files')  # 路径：/app/files
    FILE_CATEGORIES = {
        'pdf': {'dir': 'pdf', 'extensions': ['pdf']},
        'word': {'dir': 'word', 'extensions': ['doc', 'docx']},
        'excel': {'dir': 'excel', 'extensions': ['xls', 'xlsx']},
        'images': {'dir': 'images', 'extensions': ['jpg', 'jpeg', 'png', 'gif']}
    }

    # 确保文件目录存在（群晖首次启动创建）
    @classmethod
    def ensure_directories(cls):
        for category in cls.FILE_CATEGORIES.values():
            dir_path = os.path.join(cls.FILE_STORAGE_PATH, category['dir'])
            if not os.path.exists(dir_path):
                os.makedirs(dir_path, exist_ok=True)
                os.chmod(dir_path, 0o775)  # 群晖权限适配
        os.chmod(cls.FILE_STORAGE_PATH, 0o775)
