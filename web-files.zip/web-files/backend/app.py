from flask import Flask, request, jsonify, send_file
from flask_jwt_extended import (
    JWTManager, create_access_token, jwt_required, get_jwt_identity,
    unauthorized_loader, invalid_token_loader, expired_token_loader
)
from datetime import datetime
import os
import time
import threading

# 修复：绝对路径导入（适配容器）
from backend.models import db, User, File
from backend.config import Config
from backend.utils import scan_files, get_file_statistics
from backend.init_db import init_db

# 初始化Flask应用
app = Flask(__name__)
app.config.from_object(Config)

# 确保文件目录存在（群晖需显式创建）
Config.ensure_directories()

# 初始化数据库
db.init_app(app)

# 初始化JWT
jwt = JWTManager(app)

# 初始化数据库和默认管理员（群晖首次启动必备）
with app.app_context():
    init_db()
    scan_files()  # 首次扫描文件

# 后台文件扫描线程（30秒刷新一次）
def start_file_scanner():
    while True:
        with app.app_context():
            scan_files()
        time.sleep(30)

# 启动扫描线程（守护线程，随应用退出）
scanner_thread = threading.Thread(target=start_file_scanner, daemon=True)
scanner_thread.start()

# ---------------------- 错误处理（群晖调试友好） ----------------------
@jwt.unauthorized_loader
def unauthorized_response(_):
    return jsonify({"message": "请先登录"}), 401

@jwt.invalid_token_loader
def invalid_token_response(_):
    return jsonify({"message": "无效的令牌"}), 401

@jwt.expired_token_loader
def expired_token_response(_, __):
    return jsonify({"message": "令牌已过期，请重新登录"}), 401

@app.errorhandler(404)
def not_found(_):
    return jsonify({"message": "资源不存在"}), 404

@app.errorhandler(500)
def server_error(_):
    return jsonify({"message": "服务器内部错误"}), 500

# ---------------------- API接口 ----------------------
# 登录接口
@app.route('/api/login', methods=['POST'])
def login():
    data = request.get_json()
    username = data.get('username')
    password = data.get('password')
    
    if not username or not password:
        return jsonify({"message": "用户名和密码不能为空"}), 400
    
    user = User.query.filter_by(username=username).first()
    if not user or not user.check_password(password):
        return jsonify({"message": "用户名或密码错误"}), 401
    
    # 创建JWT令牌（有效期2小时）
    access_token = create_access_token(identity=user.id, expires_delta=False)
    return jsonify(token=access_token, user=user.to_dict()), 200

# 获取当前用户信息
@app.route('/api/user', methods=['GET'])
@jwt_required()
def get_user():
    user_id = get_jwt_identity()
    user = User.query.get(user_id)
    return jsonify(user.to_dict()) if user else jsonify({"message": "用户不存在"}), 404

# 获取文件列表（分类+搜索）
@app.route('/api/files', methods=['GET'])
@jwt_required()
def get_files():
    category = request.args.get('category', 'all')
    search = request.args.get('search', '')
    
    # 构建查询
    query = File.query
    if category != 'all' and category in Config.FILE_CATEGORIES:
        query = query.filter_by(category=category)
    if search:
        query = query.filter(File.name.ilike(f'%{search}%'))
    
    # 按修改时间降序
    files = query.order_by(File.last_modified.desc()).all()
    return jsonify([file.to_dict() for file in files])

# 获取单个文件信息
@app.route('/api/files/<int:file_id>', methods=['GET'])
@jwt_required()
def get_file(file_id):
    file = File.query.get(file_id)
    return jsonify(file.to_dict()) if file else jsonify({"message": "文件不存在"}), 404

# 预览文件
@app.route('/api/files/<int:file_id>/preview', methods=['GET'])
@jwt_required()
def preview_file(file_id):
    file = File.query.get(file_id)
    if not file or not os.path.exists(file.path):
        return jsonify({"message": "文件不存在或已删除"}), 404
    
    # 群晖适配：设置响应头避免缓存
    response = send_file(file.path)
    response.headers['Cache-Control'] = 'no-cache, no-store, must-revalidate'
    return response

# 下载文件
@app.route('/api/files/<int:file_id>/download', methods=['GET'])
@jwt_required()
def download_file(file_id):
    file = File.query.get(file_id)
    if not file or not os.path.exists(file.path):
        return jsonify({"message": "文件不存在或已删除"}), 404
    
    # 群晖适配：指定下载文件名
    return send_file(
        file.path,
        as_attachment=True,
        download_name=file.name,
        mimetype=file.mime_type
    )

# 获取文件统计
@app.route('/api/files/statistics', methods=['GET'])
@jwt_required()
def get_statistics():
    return jsonify(get_file_statistics())

# ---------------------- 启动入口（群晖兼容） ----------------------
if __name__ == '__main__':
    # 监听0.0.0.0，允许群晖容器外部访问
    app.run(host='0.0.0.0', port=5000, debug=Config.DEBUG)
