import os
import magic
from datetime import datetime
from backend.models import db, File
from backend.config import Config

# 获取文件MIME类型（群晖兼容）
def get_file_mime_type(file_path):
    try:
        # 优先使用python-magic
        mime = magic.from_file(file_path, mime=True)
        return mime if mime else 'application/octet-stream'
    except:
        # 降级处理：根据后缀判断
        ext = os.path.splitext(file_path)[1].lower()[1:]
        mime_map = {
            'pdf': 'application/pdf',
            'doc': 'application/msword',
            'docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'xls': 'application/vnd.ms-excel',
            'xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            'jpg': 'image/jpeg',
            'jpeg': 'image/jpeg',
            'png': 'image/png',
            'gif': 'image/gif'
        }
        return mime_map.get(ext, 'application/octet-stream')

# 扫描文件目录（同步到数据库）
def scan_files():
    # 遍历所有分类目录
    for category_key, category_info in Config.FILE_CATEGORIES.items():
        category_dir = os.path.join(Config.FILE_STORAGE_PATH, category_info['dir'])
        
        # 遍历目录下的文件
        for root, _, files in os.walk(category_dir):
            for filename in files:
                file_path = os.path.join(root, filename)
                file_ext = os.path.splitext(filename)[1].lower()[1:]  # 获取后缀（无点）
                
                # 跳过非目标后缀的文件
                if file_ext not in category_info['extensions']:
                    continue
                
                # 获取文件信息
                file_stat = os.stat(file_path)
                file_size = file_stat.st_size
                last_modified = datetime.fromtimestamp(file_stat.st_mtime)
                mime_type = get_file_mime_type(file_path)
                
                # 检查文件是否已在数据库中
                existing_file = File.query.filter_by(path=file_path).first()
                if existing_file:
                    # 更新文件信息（如大小、修改时间变化）
                    existing_file.size = file_size
                    existing_file.last_modified = last_modified
                    existing_file.mime_type = mime_type
                else:
                    # 新增文件记录
                    new_file = File(
                        name=filename,
                        path=file_path,
                        extension=file_ext,
                        category=category_key,
                        size=file_size,
                        mime_type=mime_type,
                        last_modified=last_modified
                    )
                    db.session.add(new_file)
    
    # 提交数据库变更
    db.session.commit()

    # 清理已删除的文件记录（数据库同步文件系统）
    all_files = File.query.all()
    for file in all_files:
        if not os.path.exists(file.path):
            db.session.delete(file)
    db.session.commit()

# 获取文件统计信息
def get_file_statistics():
    stats = {}
    for category_key in Config.FILE_CATEGORIES.keys():
        count = File.query.filter_by(category=category_key).count()
        stats[category_key] = count
    return stats
